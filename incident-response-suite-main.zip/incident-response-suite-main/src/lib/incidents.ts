export type Incident = {
  id: string;
  type: string;
  location: string;
  ward: string;
  latitude: number;
  longitude: number;
  status: string;
  heart_rate_bpm: number;
  noise_level_db: number;
  time: string;
  device: string;
};

export const mockIncidents: Incident[] = [
  { id: "INC-2847", type: "Distress signal", location: "Umsinga, Tugela Ferry", ward: "Umsinga rural", latitude: -28.746, longitude: 30.447, status: "Active", heart_rate_bpm: 148, noise_level_db: 824, time: "2 min ago", device: "NODE-MS-042" },
  { id: "INC-2846", type: "Assault reported", location: "Inanda, Newtown", ward: "Inanda township", latitude: -29.729, longitude: 30.943, status: "Active", heart_rate_bpm: 136, noise_level_db: 782, time: "5 min ago", device: "NODE-IN-018" },
  { id: "INC-2845", type: "Distress signal", location: "Umsinga, Tugela Ferry", ward: "Umsinga rural", latitude: -28.751, longitude: 30.456, status: "Active", heart_rate_bpm: 121, noise_level_db: 647, time: "8 min ago", device: "NODE-MS-033" },
  { id: "INC-2844", type: "Incident under review", location: "Inanda, Lindelani", ward: "Inanda township", latitude: -29.716, longitude: 30.927, status: "Monitoring", heart_rate_bpm: 94, noise_level_db: 410, time: "12 min ago", device: "NODE-IN-007" },
  { id: "INC-2843", type: "Distress signal", location: "Umsinga, Tugela Ferry", ward: "Umsinga rural", latitude: -28.742, longitude: 30.439, status: "Active", heart_rate_bpm: 142, noise_level_db: 760, time: "16 min ago", device: "NODE-MS-051" },
  { id: "INC-2842", type: "Distress signal", location: "Inanda, Ohlange", ward: "Inanda township", latitude: -29.739, longitude: 30.953, status: "En Route", heart_rate_bpm: 107, noise_level_db: 534, time: "21 min ago", device: "NODE-IN-024" },
  { id: "INC-2841", type: "Assault reported", location: "Umsinga, Tugela Ferry", ward: "Umsinga rural", latitude: -28.757, longitude: 30.444, status: "Resolved", heart_rate_bpm: 89, noise_level_db: 391, time: "34 min ago", device: "NODE-MS-039" },
  { id: "INC-2840", type: "Distress signal", location: "Inanda, Newtown", ward: "Inanda township", latitude: -29.731, longitude: 30.947, status: "Monitoring", heart_rate_bpm: 104, noise_level_db: 583, time: "42 min ago", device: "NODE-IN-011" },
  { id: "INC-2839", type: "Incident under review", location: "Inanda, Ohlange", ward: "Inanda township", latitude: -29.744, longitude: 30.955, status: "Resolved", heart_rate_bpm: 82, noise_level_db: 312, time: "1 hr ago", device: "NODE-IN-006" },
];

const text = (value: unknown, fallback: string) => typeof value === "string" && value.trim() ? value : fallback;
const number = (value: unknown, fallback: number) => {
  const result = Number(value);
  return Number.isFinite(result) ? result : fallback;
};

export function normalizeIncidents(payload: unknown): Incident[] {
  const rows = Array.isArray(payload) ? payload : payload && typeof payload === "object" ? (payload as Record<string, unknown>)["incidents"] ?? (payload as Record<string, unknown>)["data"] : null;
  if (!Array.isArray(rows)) throw new Error("Incident feed did not return an incident list");
  return rows.filter((row): row is Record<string, unknown> => row !== null && typeof row === "object")
    .map((row, index) => ({
      id: String(row["id"] ?? row["incident_id"] ?? `INC-${index + 1}`),
      type: text(row["type"] ?? row["incident_type"] ?? row["category"], "Incident detected"),
      location: text(row["location"] ?? row["area"] ?? row["suburb"], "KwaZulu-Natal"),
      ward: text(row["ward"] ?? row["ward_name"], "Unassigned ward"),
      latitude: number(row["latitude"], NaN),
      longitude: number(row["longitude"], NaN),
      status: text(row["status"], "Active"),
      heart_rate_bpm: number(row["heart_rate_bpm"], 0),
      noise_level_db: number(row["noise_level_db"], 0),
      time: text(row["time"] ?? row["timestamp"] ?? row["created_at"], "Recently"),
      device: text(row["device"] ?? row["device_id"] ?? row["node_id"], "UNKNOWN NODE"),
    }));
}

export const isActive = (incident: Incident) => incident.status.toLowerCase() === "active";
export const isEnRoute = (incident: Incident) => incident.status.toLowerCase() === "en route";
export const isVerified = (incident: Incident) => incident.noise_level_db > 700 && incident.heart_rate_bpm > 130;

// Greedy geographic density clustering (3.5 km neighborhood) keeps nearby detections together.
export function getHotspots(incidents: Incident[]) {
  const valid = incidents.filter((item) => Number.isFinite(item.latitude) && Number.isFinite(item.longitude));
  const clusters: { latitude: number; longitude: number; count: number; location: string }[] = [];
  for (const item of valid) {
    const nearby = clusters.find((cluster) => {
      const latKm = (item.latitude - cluster.latitude) * 111;
      const lonKm = (item.longitude - cluster.longitude) * 96;
      return Math.hypot(latKm, lonKm) < 3.5;
    });
    if (nearby) {
      nearby.latitude = (nearby.latitude * nearby.count + item.latitude) / (nearby.count + 1);
      nearby.longitude = (nearby.longitude * nearby.count + item.longitude) / (nearby.count + 1);
      nearby.count++;
    } else clusters.push({ latitude: item.latitude, longitude: item.longitude, count: 1, location: item.location.split(",")[0] ?? item.location });
  }
  return clusters.sort((a, b) => b.count - a.count).slice(0, 3);
}