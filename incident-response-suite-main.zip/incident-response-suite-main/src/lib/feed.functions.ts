import { createServerFn } from "@tanstack/react-start";
import { mockIncidents, normalizeIncidents } from "./incidents";

const BASE = "http://localhost:5000/api";

export const getIncidents = createServerFn({ method: "GET" }).handler(async () => {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2500);
  try {
    const response = await fetch(`${BASE}/incidents`, { signal: controller.signal, cache: "no-store" });
    if (!response.ok) throw new Error(`Feed returned ${response.status}`);
    return { incidents: normalizeIncidents(await response.json()), live: true };
  } catch {
    // A missing local service is expected in hosted previews; keep the failure out of the runtime overlay.
    return { incidents: mockIncidents, live: false };
  } finally {
    clearTimeout(timeout);
  }
});

export const dispatchIncident = createServerFn({ method: "POST" })
  .inputValidator((id: string) => {
    if (!/^[a-zA-Z0-9_-]{1,100}$/.test(id)) throw new Error("Invalid incident ID");
    return id;
  })
  .handler(async ({ data }) => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    try {
      const response = await fetch(`${BASE}/dispatch/${encodeURIComponent(data)}`, { method: "POST", signal: controller.signal });
      if (!response.ok) throw new Error(`Dispatch service returned ${response.status}`);
      return { success: true };
    } catch {
      return { success: false };
    } finally {
      clearTimeout(timeout);
    }
  });