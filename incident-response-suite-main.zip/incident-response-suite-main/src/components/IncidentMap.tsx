import { useEffect, useRef } from "react";
import type { Map as LeafletMap, LayerGroup } from "leaflet";
import type { Incident } from "@/lib/incidents";
import { getHotspots, isActive, isEnRoute } from "@/lib/incidents";
import mapAsset from "@/assets/umsinga-inanda-light.jpg.asset.json";

type Props = { incidents: Incident[]; selectedId: string | null; onSelect: (id: string) => void; mode: string };

export function IncidentMap({ incidents, selectedId, onSelect, mode }: Props) {
  const container = useRef<HTMLDivElement>(null);
  const map = useRef<LeafletMap | null>(null);
  const layers = useRef<LayerGroup | null>(null);
  const leaflet = useRef<typeof import("leaflet") | null>(null);

  useEffect(() => {
    let mounted = true;
    import("leaflet").then((L) => {
      if (!mounted || !container.current || map.current) return;
      leaflet.current = L;
      const instance = L.map(container.current, { zoomControl: false, attributionControl: false, scrollWheelZoom: false, doubleClickZoom: false, dragging: true, minZoom: 7, maxZoom: 12 });
      const bounds: [[number, number], [number, number]] = [[-30.751277776257812, 29.53125], [-27.68352808378776, 32.34375]];
      L.imageOverlay(mapAsset.url, bounds).addTo(instance);
      instance.fitBounds([[-29.84, 30.20], [-28.53, 31.18]], { padding: [18, 18] });
      map.current = instance;
      layers.current = L.layerGroup().addTo(instance);
      window.dispatchEvent(new Event("baas-map-ready"));
    });
    return () => { mounted = false; map.current?.remove(); map.current = null; layers.current = null; };
  }, []);

  useEffect(() => {
    const render = () => {
      const L = leaflet.current;
      const group = layers.current;
      if (!L || !group) return;
      group.clearLayers();
      getHotspots(incidents).filter((spot) => mode !== "news" || spot.count > 1).forEach((spot, index) => {
        L.circle([spot.latitude, spot.longitude], { radius: 1800 + Math.min(spot.count, 5) * 500, color: "#d7a658", weight: 1, opacity: .7, fillColor: "#d7a658", fillOpacity: .07, className: "radar-circle" }).addTo(group);
        L.circle([spot.latitude, spot.longitude], { radius: 350 + spot.count * 170, color: "#d7a658", weight: 1, opacity: .5, fillOpacity: 0, dashArray: "3 5" }).addTo(group);
        L.marker([spot.latitude, spot.longitude], { icon: L.divIcon({ className: "hotspot-label", html: `<span>0${index + 1} / ${spot.location.toUpperCase()} · ${spot.count}</span>`, iconSize: [160, 20], iconAnchor: [-11, 12] }), interactive: false }).addTo(group);
      });
      if (mode === "news") return;
      incidents.filter((item) => Number.isFinite(item.latitude) && Number.isFinite(item.longitude)).forEach((item) => {
        const state = isEnRoute(item) ? "enroute" : isActive(item) ? "active" : "quiet";
        const marker = L.marker([item.latitude, item.longitude], {
          icon: L.divIcon({ className: `incident-marker ${state} ${selectedId === item.id ? "selected" : ""} ${mode === "news" ? "media-marker" : ""}`, html: '<span class="marker-pulse"></span><span class="marker-core"></span>', iconSize: [30, 30], iconAnchor: [15, 15] }),
          zIndexOffset: selectedId === item.id ? 1000 : 0,
        }).addTo(group);
        marker.on("click", () => onSelect(item.id));
        marker.bindTooltip(mode === "news" ? `${item.ward} · ${item.type}` : `${item.id} · ${item.location}`, { direction: "top", offset: [0, -12], className: "tactical-tooltip" });
      });
    };
    window.addEventListener("baas-map-ready", render);
    render();
    return () => window.removeEventListener("baas-map-ready", render);
  }, [incidents, selectedId, onSelect, mode]);

  return <div className="map-canvas" ref={container} aria-label="Interactive incident map of rural Umsinga and Inanda township" />;
}