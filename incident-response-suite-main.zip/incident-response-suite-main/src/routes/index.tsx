import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Activity, ArrowDownToLine, ArrowRight, Bell, ChevronDown, CircleHelp, Clock3, Crosshair, Gauge, MapPin, Radio, RadioTower, Search, Shield, ShieldAlert, Siren, Wifi, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { IncidentMap } from "@/components/IncidentMap";
import { dispatchIncident, getIncidents } from "@/lib/feed.functions";
import { getHotspots, isActive, isEnRoute, isVerified, mockIncidents, type Incident } from "@/lib/incidents";

type Mode = "network" | "saps" | "news";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Command Centre | BAAS Solutions" },
    { name: "description", content: "BAAS Solutions security command centre focused on rural Umsinga and Inanda township, with incident dispatch and anonymized analytics." },
    { property: "og:title", content: "BAAS Solutions | Security Command Centre" },
    { property: "og:description", content: "Monitor incidents, community mesh infrastructure and trends across rural Umsinga and Inanda township." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Dashboard,
});

function PulseChart({ value = 105, subdued = false }: { value?: number; subdued?: boolean }) {
  const peaks = Array.from({ length: 4 }, (_, i) => {
    const x = i * 90;
    const height = Math.min(43, 14 + value / 5);
    return `${x},38 ${x + 18},38 ${x + 25},34 ${x + 31},42 ${x + 38},${38 - height} ${x + 44},57 ${x + 51},38 ${x + 90},38`;
  }).join(" ");
  return <svg className={`pulse-chart ${subdued ? "subdued" : ""}`} viewBox="0 0 360 75" preserveAspectRatio="none" aria-label={`Heart rate ${value} beats per minute`}><path className="pulse-guide" d="M0 38H360"/><polyline className="pulse-line" points={peaks}/></svg>;
}

function NetworkChart({ tick }: { tick: number }) {
  const points = Array.from({ length: 47 }, (_, i) => `${i * 8},${33 - Math.sin(i * .85 + tick * .5) * 5 - (i % 9 === 0 ? 14 : 0) - (i % 13 === 0 ? 9 : 0)}`).join(" ");
  return <svg className="network-chart" viewBox="0 0 368 65" preserveAspectRatio="none" aria-label="Live mesh network heartbeat"><path d="M0 33H368" className="pulse-guide"/><polyline points={points} className="network-line" /></svg>;
}

function downloadBulletin(incidents: Incident[], demo: boolean) {
  const wards = Object.entries(incidents.reduce<Record<string, number>>((acc, row) => { acc[row.ward] = (acc[row.ward] ?? 0) + 1; return acc; }, {})).sort((a, b) => b[1] - a[1]);
  const types = Object.entries(incidents.reduce<Record<string, number>>((acc, row) => { acc[row.type] = (acc[row.type] ?? 0) + 1; return acc; }, {})).sort((a, b) => b[1] - a[1]);
  const safe = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c);
  const date = new Date().toLocaleString("en-ZA", { dateStyle: "full", timeStyle: "short", timeZone: "Africa/Johannesburg" });
  const topWard = wards[0];
  const html = `<!doctype html><html lang="en"><meta charset="utf-8"><title>KZN Incident Bulletin</title><style>body{font-family:Arial,sans-serif;max-width:760px;margin:60px auto;padding:0 24px;color:#17211d;line-height:1.6}header{border-top:6px solid #178b56;border-bottom:1px solid #ccc;padding:25px 0}small{color:#537063;letter-spacing:2px}h1{font-size:36px;margin:8px 0}h2{margin-top:38px;border-bottom:1px solid #ddd;padding-bottom:8px}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #e5e9e5;text-align:left}footer{margin-top:45px;font-size:12px;color:#66736d}</style><header><small>BAAS SOLUTIONS / NEWS DESK</small><h1>KwaZulu-Natal Incident Bulletin</h1><p>${safe(date)} · ${demo ? "Demonstration data — not for broadcast" : "Live feed summary"}</p></header><h2>News flash</h2><p>${incidents.length} incidents recorded across ${wards.length} wards in the current feed. ${topWard ? `Highest reported frequency: ${safe(topWard[0])} (${topWard[1]} incidents).` : "No ward activity recorded."} ${incidents.filter(isActive).length} incidents are currently active.</p><h2>Incidents by ward</h2><table><tr><th>Ward</th><th>Incidents</th></tr>${wards.map(([ward, count]) => `<tr><td>${safe(ward)}</td><td>${count}</td></tr>`).join("")}</table><h2>Reported categories</h2><table><tr><th>Category</th><th>Incidents</th></tr>${types.map(([type, count]) => `<tr><td>${safe(type)}</td><td>${count}</td></tr>`).join("")}</table><footer>Aggregated, anonymized data only. No names, device identifiers, exact coordinates, biometrics or individual case records included. Confirm details with authorities before broadcast.</footer></html>`;
  const url = URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" }));
  const link = document.createElement("a"); link.href = url; link.download = `kzn-incident-bulletin-${new Date().toISOString().slice(0, 10)}.html`; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function Dashboard() {
  const [mode, setMode] = useState<Mode>("network");
  const [incidents, setIncidents] = useState<Incident[]>(mockIncidents);
  const [source, setSource] = useState<"checking" | "live" | "demo">("checking");
  const [selectedId, setSelectedId] = useState<string | null>(mockIncidents[0]?.id ?? null);
  const [tick, setTick] = useState(0);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All statuses");
  const [dispatching, setDispatching] = useState(false);
  const [notice, setNotice] = useState("");
  const fetchIncidents = useServerFn(getIncidents);
  const sendDispatch = useServerFn(dispatchIncident);

  useEffect(() => {
    let active = true;
    const refresh = async () => {
      try {
        const result = await fetchIncidents();
        if (active) {
          setIncidents(result.incidents);
          setSource(result.live ? "live" : "demo");
        }
      } catch {
        if (active) { setIncidents(mockIncidents); setSource("demo"); }
      }
    };
    void refresh();
    const poll = setInterval(refresh, 10000);
    return () => { active = false; clearInterval(poll); };
  }, [fetchIncidents]);
  useEffect(() => { const timer = setInterval(() => setTick((n) => n + 1), 2000); return () => clearInterval(timer); }, []);
  useEffect(() => { if (!notice) return; const timer = setTimeout(() => setNotice(""), 5000); return () => clearTimeout(timer); }, [notice]);

  const select = useCallback((id: string) => setSelectedId(id), []);
  const selected = incidents.find((item) => item.id === selectedId) ?? incidents[0];
  const activeCount = incidents.filter(isActive).length;
  const verifiedCount = incidents.filter(isVerified).length;
  const hotspots = useMemo(() => getHotspots(incidents), [incidents]);
  const wards = useMemo(() => Object.entries(incidents.reduce<Record<string, number>>((acc, item) => { acc[item.ward] = (acc[item.ward] ?? 0) + 1; return acc; }, {})).sort((a, b) => b[1] - a[1]), [incidents]);
  const filtered = incidents.filter((item) => (statusFilter === "All statuses" || item.status.toLowerCase() === statusFilter.toLowerCase()) && (mode === "news" ? `${item.ward} ${item.type}` : `${item.id} ${item.location} ${item.type}`).toLowerCase().includes(query.toLowerCase()));

  const handleDispatch = async () => {
    if (!selected || !isActive(selected) || dispatching) return;
    const id = selected.id;
    setIncidents((rows) => rows.map((row) => row.id === id ? { ...row, status: "En Route" } : row));
    if (source !== "live") { setNotice("Demo dispatch simulated. No responders were contacted."); return; }
    setDispatching(true);
    try { const result = await sendDispatch({ data: id }); if (!result.success) throw new Error("Dispatch unavailable"); setNotice(`Dispatch sent for ${id}. Responders en route.`); }
    catch { setIncidents((rows) => rows.map((row) => row.id === id ? { ...row, status: "Active" } : row)); setNotice("Dispatch could not be sent. Please retry."); }
    finally { setDispatching(false); }
  };

  return <div className="command-shell">
    <aside className="sidebar">
      <div className="brand-mark"><div className="brand-symbol"><Shield size={24} strokeWidth={1.8}/><span className="brand-symbol-line"/></div><div><strong>BAAS<span className="brand-green">.</span></strong><small>SOLUTIONS</small></div></div>
      <div className="sidebar-caption">COMMAND PLATFORM <span>01 / 03</span></div>
      <nav className="side-nav" aria-label="Command navigation">
        <div className="side-group-title">WORKSPACE</div>
        <div className="side-link active"><Crosshair size={17}/> Command Overview <span className="side-active-mark"/></div>
        <div className="side-link"><MapPin size={17}/> Incident Radar <span className="nav-count">{activeCount}</span></div>
        <div className="side-link"><Activity size={17}/> Biometric Streams</div>
        <div className="side-link"><RadioTower size={17}/> Mesh Infrastructure</div>
        <div className="side-group-title second">INTELLIGENCE</div>
        <div className="side-link"><Gauge size={17}/> Analytics</div>
        <div className="side-link"><ShieldAlert size={17}/> Case Registry</div>
      </nav>
      <div className="sidebar-bottom"><div className="sidebar-system"><span className={`status-dot ${source === "live" ? "green" : "amber"}`}/><div><strong>{source === "live" ? "SYSTEM OPERATIONAL" : source === "checking" ? "CONNECTING TO FEED" : "DEMO FEED ACTIVE"}</strong><small>{source === "live" ? "Local incident feed connected" : "Local incident feed unavailable"}</small></div></div><div className="sidebar-footer"><span>BAAS COMMAND OS</span><span>v2.4.0</span></div></div>
    </aside>

    <main className="main-area">
      <header className="topbar"><div className="topbar-left"><span className="topbar-section">OPERATIONS</span><span className="crumb-separator">/</span><span className="topbar-current">Command Overview</span><span className="region-pill"><span className="status-dot green"/> KZN REGION</span></div><div className="topbar-right"><span className="clock-label"><Clock3 size={14}/><LiveClock tick={tick}/></span><span className="topbar-divider"/><span className="secure-label"><Shield size={14}/> SECURE SESSION</span><span className="topbar-divider"/><div className="operator-avatar">BO</div></div></header>
      <div className="page-content">
        <div className="heading-row"><div><div className="eyebrow"><span className="eyebrow-line"/> UMSINGA RURAL / INANDA TOWNSHIP <span className="eyebrow-code">BAAS — 001</span></div><h1>Command <span>Overview</span></h1><p className="heading-subtitle">Incident intelligence and network operations across rural Umsinga and Inanda township.</p></div><div className="heading-actions"><span className="last-sync"><span className="status-dot green"/> {source === "live" ? "LIVE FEED" : source === "checking" ? "CONNECTING" : "DEMO DATA"} <span className="sync-divider">·</span> UPDATED {source === "live" ? "JUST NOW" : "LOCALLY"}</span>{mode === "news" && <Button className="export-button" onClick={() => downloadBulletin(incidents, source !== "live")}><ArrowDownToLine size={15}/> Export Anonymized Incident Report</Button>}</div></div>

        <div className="mode-toolbar"><div className="mode-label">OPERATIONAL VIEW <span className="mode-label-line"/></div><div className="mode-list" role="tablist" aria-label="User mode filters"><Button role="tab" aria-selected={mode === "network"} variant="ghost" className={`mode-button ${mode === "network" ? "selected" : ""}`} onClick={() => setMode("network")}><RadioTower size={15}/> BAAS Network Health Mode</Button><Button role="tab" aria-selected={mode === "saps"} variant="ghost" className={`mode-button ${mode === "saps" ? "selected" : ""}`} onClick={() => setMode("saps")}><Siren size={15}/> SAPS Dispatch Mode</Button><Button role="tab" aria-selected={mode === "news"} variant="ghost" className={`mode-button ${mode === "news" ? "selected" : ""}`} onClick={() => setMode("news")}><Gauge size={15}/> News Media Analytics Mode</Button></div><div className="mode-end"><span className="mode-online-dot"/> ALL SYSTEMS {source === "live" ? "NOMINAL" : "SIMULATED"}</div></div>

        <div className="metrics-grid"><Metric icon={<ShieldAlert size={20}/>} label={mode === "news" ? "REPORTED INCIDENTS" : "ACTIVE INCIDENTS"} value={mode === "news" ? incidents.length : activeCount} change={mode === "news" ? "Across current feed" : "Awaiting response"} tone="red" bar={68}/><Metric icon={<Crosshair size={20}/>} label="RADAR HOTSPOTS" value={hotspots.length} change="High-density clusters" tone="amber" bar={52}/><Metric icon={<Activity size={20}/>} label={mode === "news" ? "WARDS WITH REPORTS" : "BIOMETRIC MATCHES"} value={mode === "news" ? wards.length : verifiedCount} change={mode === "news" ? "Regional coverage" : "Dual-signal verified"} tone="green" bar={mode === "news" ? 65 : 42}/><Metric icon={<RadioTower size={20}/>} label="MESH NETWORK" value="SIM" change="Sample telemetry only" tone="green" bar={96}/></div>

        <div className="primary-grid">
          <section className="panel map-panel"><div className="panel-heading"><div><div className="panel-kicker">GEOSPATIAL INTELLIGENCE <span> / 01</span></div><h2>{mode === "news" ? "Regional incident heatmap" : "Incident radar"}</h2></div><div className="map-heading-right"><span className="map-live"><span className="status-dot red"/>{mode === "news" ? "AGGREGATED VIEW" : "INCIDENT TRACKING"}</span><Crosshair size={16} className="muted-icon"/></div></div><div className="map-wrap"><IncidentMap incidents={incidents} selectedId={selected?.id ?? null} onSelect={select} mode={mode}/><div className="map-scale">KZN / UMSINGA RURAL · INANDA TOWNSHIP</div><div className="map-legend">{mode !== "news" && <><span><i className="legend-dot active"/> Active</span><span><i className="legend-dot enroute"/> En route</span></>}<span><i className="legend-ring"/> Radar zone</span></div></div><div className="map-footer"><span><Crosshair size={14}/> {mode === "news" ? `${wards.length} REPORTING AREAS` : `${incidents.filter((item) => Number.isFinite(item.latitude) && Number.isFinite(item.longitude)).length} GEOLOCATED SIGNALS`}</span><span>RADAR CLUSTERS <b>{hotspots.length} ACTIVE</b></span></div></section>

          <section className="panel stream-panel"><div className="panel-heading"><div><div className="panel-kicker">{mode === "news" ? "REGIONAL INTELLIGENCE" : "BIOMETRIC TELEMETRY"} <span> / 02</span></div><h2>{mode === "news" ? "Ward frequency" : mode === "saps" ? "Priority response" : "Biometric stream"}</h2></div><div className="live-indicator"><span className={`status-dot ${source === "live" ? "green" : "amber"}`}/>{mode === "news" ? "ANONYMIZED" : source === "live" ? "FEED DATA" : "DEMO DATA"}</div></div>
            {mode === "news" ? <div className="ward-analytics"><p className="analytics-intro">Incident concentration by ward in the current reporting window.</p>{wards.slice(0, 5).map(([ward, count], index) => <div className="ward-row" key={ward}><span className="ward-rank">0{index + 1}</span><span className="ward-name">{ward}</span><span className="ward-bar"><i style={{ width: `${Math.max(8, count / Math.max(1, wards[0]?.[1] ?? 1) * 100)}%` }}/></span><strong>{count}</strong></div>)}<div className="analytics-summary"><span>TOTAL RECORDED</span><strong>{incidents.length} <small>incidents</small></strong></div><p className="privacy-note"><Shield size={14}/> Individual records, coordinates, and biometric signals are hidden in this view.</p></div> : selected ? <div className="stream-content"><div className="stream-incident"><div><span className="node-label">WEARABLE NODE / {selected.device}</span><strong>{selected.type}</strong><span className="stream-location"><MapPin size={12}/>{selected.location} <span>·</span> {selected.time}</span></div><span className={`incident-status ${isEnRoute(selected) ? "enroute" : isActive(selected) ? "active" : "quiet"}`}>{selected.status.toUpperCase()}</span></div><div className="heart-monitor"><div className="monitor-heading"><span><Activity size={14}/> HEART RATE SIGNAL</span><span>{source === "live" ? "ECG / FEED" : "ECG / DEMO"}</span></div><PulseChart value={selected.heart_rate_bpm}/><div className="heart-reading"><strong>{selected.heart_rate_bpm}</strong><span>BPM <i/> {selected.heart_rate_bpm > 130 ? "ELEVATED" : "STABLE"}</span></div></div><div className="telemetry-values"><div><span>ACOUSTIC LEVEL</span><strong>{selected.noise_level_db}<small> dB</small></strong></div><div><span>HEART RATE</span><strong>{selected.heart_rate_bpm}<small> bpm</small></strong></div><div><span>DUAL SIGNAL</span><strong className={isVerified(selected) ? "red-text" : "green-text"}>{isVerified(selected) ? "MATCH" : "CLEAR"}</strong></div></div>{isVerified(selected) && <div className="verification-alert"><ShieldAlert size={18}/><span>BIOMETRIC MATCH VERIFIED <small>HIGH PROBABILITY CRITICAL CRIME</small></span><span className="alert-chevron">›</span></div>}{mode === "saps" && <Button className="dispatch-button" disabled={!isActive(selected) || dispatching} onClick={handleDispatch}><Siren size={16}/>{dispatching ? "CONTACTING DISPATCH..." : isEnRoute(selected) ? "RESPONDERS EN ROUTE" : "Dispatch Community Siren / Responders"}<ArrowRight size={16}/></Button>}</div> : <div className="empty-panel">No incidents are currently available.</div>}
          </section>
        </div>

        <div className="secondary-grid"><section className="panel feed-panel"><div className="panel-heading"><div><div className="panel-kicker">{mode === "news" ? "ANONYMIZED FEED" : "INCIDENT FEED"} <span> / 03</span></div><h2>{mode === "news" ? "Regional reports" : "Recent incidents"}</h2></div><div className="feed-tools"><div className="search-box"><Search size={14}/><input aria-label="Search incidents" placeholder={mode === "news" ? "Search ward or category" : "Search incidents"} value={query} onChange={(e) => setQuery(e.target.value)}/>{query && <Button variant="ghost" size="icon" className="clear-search" onClick={() => setQuery("")} aria-label="Clear search"><X size={13}/></Button>}</div><label className="select-wrap"><select aria-label="Filter by status" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}><option>All statuses</option><option>Active</option><option>En Route</option><option>Monitoring</option><option>Resolved</option></select><ChevronDown size={13}/></label></div></div><div className="feed-table-wrap"><table className="feed-table"><thead><tr><th>{mode === "news" ? "WARD" : "INCIDENT ID"}</th><th>TYPE / LOCATION</th><th>STATUS</th><th>DETECTED</th><th className="arrow-col"></th></tr></thead><tbody>{filtered.slice(0, 6).map((item) => <tr key={item.id} className={selected?.id === item.id && mode !== "news" ? "row-selected" : ""} onClick={() => mode !== "news" && select(item.id)} tabIndex={mode !== "news" ? 0 : undefined} onKeyDown={(e) => { if (mode !== "news" && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); select(item.id); } }}><td className="id-cell"><span className={`row-status-dot ${isEnRoute(item) ? "green" : isActive(item) ? "red" : "muted"}`}/>{mode === "news" ? item.ward : item.id}</td><td><strong>{item.type}</strong><small>{mode === "news" ? "KwaZulu-Natal" : item.location}</small></td><td><span className={`table-status ${isEnRoute(item) ? "enroute" : isActive(item) ? "active" : "quiet"}`}>{item.status}</span></td><td className="time-cell">{mode === "news" ? "Current window" : item.time}</td><td className="arrow-col">{mode !== "news" && <ArrowRight size={14}/>}</td></tr>)}</tbody></table>{filtered.length === 0 && <div className="empty-table">No matching incidents found.</div>}</div><div className="feed-footer"><span>SHOWING {Math.min(filtered.length, 6)} OF {filtered.length} INCIDENTS</span><span>{source === "live" ? "AUTO-REFRESH EVERY 10S" : "DEMONSTRATION FEED"} <span className="footer-flash">●</span></span></div></section>
          <section className="panel infrastructure-panel"><div className="panel-heading"><div><div className="panel-kicker">{mode === "news" ? "REPORTING WINDOW" : mode === "saps" ? "TACTICAL OVERVIEW" : "INFRASTRUCTURE TELEMETRY"} <span> / 04</span></div><h2>{mode === "news" ? "Activity overview" : mode === "saps" ? "Response status" : "Network health"}</h2></div><Radio size={17} className="muted-icon"/></div>{mode === "network" ? <div className="network-content"><div className="network-status"><span><span className="status-dot amber"/> 915 MHz MESH GRID</span><span>SIMULATED TELEMETRY</span></div><NetworkChart tick={tick}/><div className="network-stat-grid"><div><small>SCAN RATE FREQUENCY</small><strong>450<span> Hz</span></strong></div><div><small>PACKET LOSS</small><strong>0.02<span> %</span></strong></div><div><small>CHECK-IN INTERVAL</small><strong>2.0<span> s</span></strong></div><div><small>NETWORK UPTIME</small><strong>99.98<span> %</span></strong></div></div><div className="network-bottom"><Wifi size={14}/> SAMPLE MESH METRICS <span>·</span> NOT LIVE HARDWARE DATA</div></div> : mode === "saps" ? <div className="response-content"><div className="response-big"><span className="status-dot red"/><strong>{activeCount}</strong><span>AWAITING RESPONSE</span></div><div className="response-stat"><span>Responders en route</span><strong className="green-text">{incidents.filter(isEnRoute).length}</strong></div><div className="response-stat"><span>Verified critical signals</span><strong className="red-text">{verifiedCount}</strong></div><div className="response-stat"><span>Priority hot zones</span><strong className="amber-text">{hotspots.length}</strong></div><p>Select an active incident from the feed or map to dispatch responders.</p></div> : <div className="timeline-content"><p>Incidents by reporting ward in this feed</p><div className="timeline-bars">{wards.map(([, count], i) => <span key={i} style={{ height: `${count / Math.max(1, wards[0]?.[1] ?? 1) * 100}%` }}/>)}</div><div className="timeline-labels">{wards.map(([ward]) => <span key={ward}>{ward}</span>)}</div><div className="analytics-summary"><span>WARDS COVERED</span><strong>{wards.length} <small>wards</small></strong></div><p className="privacy-note"><Shield size={14}/> Aggregate counts only. No individual records exported.</p></div>}</section></div>
        <footer className="main-footer"><span>© 2026 BAAS SOLUTIONS <span className="footer-slash">/</span> COMMAND PLATFORM</span><span>BUILT FOR THE FIELD. ENGINEERED FOR CERTAINTY.</span><span><CircleHelp size={13}/> SUPPORT <span className="footer-slash">/</span> SYSTEM STATUS</span></footer>
      </div>
    </main>
    {notice && <div role="status" className="toast-notice"><Bell size={15}/>{notice}<Button variant="ghost" size="icon" onClick={() => setNotice("")} aria-label="Dismiss notification"><X size={15}/></Button></div>}
  </div>;
}

function LiveClock({ tick }: { tick: number }) {
  const [time, setTime] = useState("--:--:--");
  useEffect(() => setTime(new Date().toLocaleTimeString("en-GB", { timeZone: "Africa/Johannesburg", hour12: false })), [tick]);
  return <span>{time} SAST</span>;
}

function Metric({ icon, label, value, change, tone, bar }: { icon: React.ReactNode; label: string; value: string | number; change: string; tone: string; bar: number }) {
  return <div className={`metric-card metric-${tone}`}><div className="metric-upper"><span className="metric-label">{label}</span><span className="metric-icon">{icon}</span></div><div className="metric-value">{value}</div><div className="metric-foot"><span className="metric-mini-dot"/>{change}</div><div className="metric-track"><i style={{ width: `${bar}%` }}/></div></div>;
}