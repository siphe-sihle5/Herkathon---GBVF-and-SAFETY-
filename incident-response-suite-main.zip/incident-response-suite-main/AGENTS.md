<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the external local incident feed and dispatch calls inside TanStack server functions; browser requests to localhost would point at each viewer’s device and expose operational calls.
- The dashboard uses a locally served light KZN image overlay with Leaflet spanning rural Umsinga and Inanda township for coordinate-accurate markers; this avoids runtime third-party tile requests.
- Treat the unavailable local feed as explicit demonstration data and never claim a simulated dispatch contacted responders.
