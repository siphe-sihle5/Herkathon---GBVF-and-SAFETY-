# Crimson Beacon Dashboard

Colours should be black as background, green and red for signals.

Build a premium, high-fidelity Enterprise Security Command Dashboard optimized for BAAS Solutions, designed to be white-labeled and sold directly to SAPS and News Agencies. 

The system must connect to the local SQL JSON data feed at "http://localhost:5000/api/incidents" and implement a highly advanced, technical UI inspired by modern tactical operations platforms.

Implement three distinct User Mode filters at the top of the interface:
1. "BAAS Network Health Mode" (Shows system analytics, scan frequencies, and hardware diagnostics).
2. "SAPS Dispatch Mode" (Prioritizes raw tactical responses, hot zones, and case status management).
3. "News Media Analytics Mode" (Anonymizes personal records but emphasizes statistical trends, timeline frequencies, and macro heatmaps for broadcast journalism).

Core UI & Component Features:
1. Spatial Incident Radar Hotspots Map:
- Render a dark-themed map of KZN (centered around Durban/Umlazi/Inanda). Plot interactive markers using 'latitude' and 'longitude'.
- Implement a geographic 'Radar Circle' layer that dynamically calculates and overlays glowing neon-amber radius boundary fields over the top 3 high-density incident coordinates ('incident radar hotspots') based on clustering.
- Active incident rows (status = 'Active') must display as a pulsing hyper-bright crimson beacon.

2. Real-Time Biometric Stream Grid:
- In the center panel, create a running digital telemetry monitor representing the live data incoming from the wearable nodes.
- For the latest incidents, display a real-time 'Biometric Stream' component showing an animated EKG/Pulse line metric mapped to the 'heart_rate_bpm'. 
- Highlight the 'Dual Verification Status': If both 'noise_level_db' > 700 and 'heart_rate_bpm' > 130, flash a high-visibility badge saying "BIOMETRIC MATCH VERIFIED - HIGH PROBABILITY CRITICAL CRIME".

3. Hardware Network Analytics Panel (For BAAS Solutions operations):
- Add a dedicated infrastructure telemetry widget showing 'Scan Rate Frequency'. Simulate a live system health heartbeat graph refreshing every 2 seconds, displaying network check-in intervals (e.g., "915 MHz Mesh Grid Online | Local Scan Rate: 450Hz | Packet Loss: 0.02%"). This proves to SAPS that the community mesh infrastructure is online and active without Eskom network dropouts.

4. Multi-Agency Utility Layout:
- For SAPS: Include the 'Dispatch Community Siren / Responders' button linking to `http://localhost:5000/api/dispatch/{id}` that changes active indicators to green 'En Route' markers on the map instantly.
- For News Agencies: Add an 'Export Anonymized Incident Report' button at the top right, which aggregates the frequency of local crimes per ward into a clean, ready-for-broadcast news flash bulletin layout.

Styling and Theme Aesthetics:
The application layout must be exceptionally sleek, high-end, and dark-mode optimized. Pitch black background (#000000 or deep pure black), sharp green and red indicators for status and signal telemetry, warning accents, and digital grid system layout borders for an authoritative tactical operations command room feel. Include robust fallback mock data simulating the API feed when the local endpoint is unreachable.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/f25dee03-2128-4b42-835d-ba3e0929d303).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
