# Three-page BAAS GBV Command Platform

## Direction
Create a high-density tactical operations interface using the supplied deep-slate, crimson, amber, and green palette. The product will prioritize rural uMsinga and township Inanda, with KZN-wide context kept secondary.

## Pages
1. **Network Health** (`/`) — BAAS mesh status, rural coverage, scan frequency, packet loss, node health, and infrastructure resilience across uMsinga and Inanda.
2. **SAPS Dispatch** (`/dispatch`) — active GBV alerts, response priorities, responder assignment, incident status, dual biometric verification, and focused hotspot mapping.
3. **Media Analytics** (`/media`) — anonymized GBVF trends, rural/township comparisons, broadcast-safe summaries, timelines, and exportable bulletin preview.

## Shared experience
- Persistent command header with three mode/page controls, live clock, system status, and urgent alert count.
- Dense but readable tactical grid, semantic severity states, responsive navigation, restrained motion, and accessible labels.
- Local incident feed integration with realistic fallback records focused on uMsinga and Inanda when the feed is unavailable.
- Interactive incident selection and instant dispatch-state updates from the SAPS page.

## Technical details
- Use TanStack routes for all three pages and shared reusable dashboard modules.
- Keep the local API integration browser-safe and gracefully handle offline/CORS failures.
- Build the geographic view as a stylized KZN operational map without requiring an external map credential.
- Define all palette, type, grid, glow, and animation values as shared semantic tokens.
- Add unique metadata for each page and verify desktop and mobile layouts in the running preview.
