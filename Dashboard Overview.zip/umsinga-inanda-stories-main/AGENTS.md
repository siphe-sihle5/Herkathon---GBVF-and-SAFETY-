<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep shared tactical dashboard primitives in `src/components/command-ui.tsx`; this preserves visual and interaction consistency across the three operational modes.
- Treat the local incident API as optional and retain realistic in-memory fallback records; the command interface must remain useful when the local feed is unreachable.
