import { createFileRoute } from "@tanstack/react-router";
import { CommandShell, Metric, NetworkNode, Panel, TacticalMap, TinyBars, icons, useIncidents } from "@/components/command-ui";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "BAAS Network Health — uMsinga & Inanda" },
    { name: "description", content: "Live BAAS mesh health and GBVF emergency infrastructure coverage for rural uMsinga and Inanda township." },
    { property: "og:title", content: "BAAS Network Health — uMsinga & Inanda" },
    { property: "og:description", content: "Live rural and township GBVF emergency network status across priority KZN communities." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: NetworkHealthPage,
});

function NetworkHealthPage() {
  const { incidents, source } = useIncidents();
  const critical = incidents.filter((incident) => incident.status === "Active").length;
  return <CommandShell eyebrow="Mode 01 / Infrastructure operations" title="Network Health Command" detail="Resilient community mesh coverage across rural and township priority zones.">
    <div className="metric-grid">
      <Metric label="Mesh Availability" value="99.98" unit="%" tone="success" note="+0.04% over 24h" icon={<icons.Signal />} />
      <Metric label="Active Sensor Nodes" value="148" tone="neutral" note="74 uMsinga · 74 Inanda" icon={<icons.Antenna />} />
      <Metric label="Local Scan Rate" value="450" unit="Hz" tone="amber" note="Sub-second distress scan" icon={<icons.Activity />} />
      <Metric label="Packet Loss" value="0.02" unit="%" tone="success" note="Within tactical threshold" icon={<icons.Radio />} />
      <Metric label="Critical Signals" value={String(critical)} tone="danger" note={`${source === "live" ? "Live SQL feed" : "Fallback operations feed"}`} icon={<icons.AlertTriangle />} />
    </div>
    <div className="dashboard-grid network-layout">
      <Panel className="map-panel" kicker="Spatial infrastructure" title="Coverage & Relay Topology" icon={<icons.Signal />} aside={<span className="panel-tag">915 MHz MESH</span>}><TacticalMap /></Panel>
      <Panel className="health-panel" kicker="Live systems" title="Mesh Pulse" icon={<icons.Activity />} aside={<span className="online-label"><i />ALL CORE SYSTEMS NOMINAL</span>}>
        <div className="health-chart"><div className="chart-value"><strong>450</strong><span>Hz average scan rate</span></div><TinyBars values={[35,44,42,59,48,63,56,78,68,72,89,82,94,78,88,96,84,91,75,89,95,87,93,99]} tone="success" /></div>
        <div className="health-rows"><div><span>Uplink integrity</span><strong>99.98%</strong></div><div><span>Average latency</span><strong>42 ms</strong></div><div><span>Eskom dependency</span><strong className="success-text">0%</strong></div><div><span>Solar reserve</span><strong>36.4 hr</strong></div></div>
      </Panel>
      <Panel className="node-panel" kicker="Field infrastructure" title="Priority Relay Nodes" icon={<icons.Wifi />} aside={<span className="panel-tag">148 TOTAL</span>}>
        <div className="node-list"><NetworkNode name="UM-TF-019" location="Tugela Ferry · uMsinga" signal={-61} battery={94} /><NetworkNode name="UM-PO-008" location="Pomeroy · uMsinga" signal={-73} battery={81} /><NetworkNode name="IN-NC-044" location="Newtown C · Inanda" signal={-57} battery={98} /><NetworkNode name="IN-AM-027" location="Amaoti · Inanda" signal={-68} battery={89} /><NetworkNode name="UM-MS-012" location="Msinga ridge relay" signal={-82} battery={63} online={false} /></div>
      </Panel>
      <Panel className="uptime-panel" kicker="72-hour resilience" title="Off-Grid Continuity" icon={<icons.ShieldCheck />}>
        <div className="continuity"><div className="radial"><span>99.9%</span><small>UPTIME</small></div><div><h3>Independent under load shedding</h3><p>All priority corridors remain connected through solar relay and local failover.</p><div className="continuity-tags"><span>18 solar relays</span><span>6 failover paths</span></div></div></div>
      </Panel>
    </div>
  </CommandShell>;
}
