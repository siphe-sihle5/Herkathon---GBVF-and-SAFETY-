import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { BiometricCard, Button, CommandShell, IncidentsTable, Metric, Panel, StatusDot, TacticalMap, icons, useIncidents } from "@/components/command-ui";
import type { Incident } from "@/lib/incident-data";

export const Route = createFileRoute("/dispatch")({
  head: () => ({ meta: [
    { title: "SAPS GBV Dispatch — BAAS Command" },
    { name: "description", content: "Prioritized GBV incident dispatch and biometric verification for uMsinga and Inanda response teams." },
    { property: "og:title", content: "SAPS GBV Dispatch — BAAS Command" },
    { property: "og:description", content: "Live tactical GBV response coordination for uMsinga and Inanda." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: DispatchPage,
});

function DispatchPage() {
  const { incidents, setIncidents, source } = useIncidents();
  const [selectedId, setSelectedId] = useState("GBV-2409");
  const selected = incidents.find((incident) => incident.id === selectedId) ?? incidents[0];
  const active = incidents.filter((incident) => incident.status === "Active").length;
  const dispatched = incidents.filter((incident) => incident.status === "En Route").length;
  const handleDispatch = async () => {
    if (!selected) return;
    setIncidents((rows) => rows.map((row) => row.id === selected.id ? { ...row, status: "En Route" } : row));
    try { await fetch(`http://localhost:5000/api/dispatch/${selected.id}`, { method: "POST" }); } catch { /* Optimistic field state remains available offline. */ }
  };
  return <CommandShell eyebrow="Mode 02 / SAPS coordinated response" title="GBV Emergency Dispatch" detail="Verified distress alerts prioritized across uMsinga rural wards and Inanda township." actions={<><span className="feed-state"><i />{source === "live" ? "SQL FEED LIVE" : "RESILIENT CACHE"}</span><Button variant="danger" onClick={handleDispatch} disabled={!selected || selected.status === "En Route"}><icons.Siren />{selected?.status === "En Route" ? "Responders En Route" : "Dispatch Responders"}</Button></>}>
    <div className="metric-grid metric-grid--dispatch">
      <Metric label="Active Alerts" value={String(active)} tone="danger" note="Immediate intervention" icon={<icons.BellRing />} />
      <Metric label="Units En Route" value={String(dispatched)} tone="amber" note="SAPS + community response" icon={<icons.Siren />} />
      <Metric label="Median Dispatch" value="02:18" tone="success" note="Target under 4 min" icon={<icons.Activity />} />
      <Metric label="Available Teams" value="07" note="3 rural · 4 township" icon={<icons.ShieldCheck />} />
    </div>
    <div className="dashboard-grid dispatch-layout">
      <Panel className="dispatch-map" kicker="Live incident radar" title="Priority Response Map" icon={<icons.Signal />} aside={<span className="panel-tag panel-tag--danger">{active} ACTIVE BEACONS</span>}><TacticalMap /></Panel>
      {selected && <Panel className="selected-panel" kicker="Selected incident" title={`${selected.id} · ${selected.locality}`} icon={<icons.AlertTriangle />} aside={<StatusDot status={selected.status} />}>
        <div className="incident-priority"><span>{selected.priority} priority</span><strong>{selected.area}</strong></div>
        <BiometricCard incident={selected} />
        <div className="response-grid"><span><small>Nearest unit</small><strong>SAPS R-14</strong></span><span><small>ETA</small><strong>08:42</strong></span><span><small>Distance</small><strong>6.8 km</strong></span><span><small>Case state</small><strong>{selected.status}</strong></span></div>
        <Button className="full-button" variant="danger" onClick={handleDispatch} disabled={selected.status === "En Route"}><icons.Siren />{selected.status === "En Route" ? "Response Activated" : "Activate Community Siren + Dispatch"}</Button>
      </Panel>}
      <Panel className="incidents-panel" kicker="Priority queue" title="Live Incident Register" icon={<icons.Radio />} aside={<span className="panel-tag">AUTO-PRIORITIZED</span>}><IncidentsTable incidents={incidents} selected={selected?.id} onSelect={(incident: Incident) => setSelectedId(incident.id)} /></Panel>
      <Panel className="streams-panel" kicker="Wearable node telemetry" title="Biometric Stream Grid" icon={<icons.HeartPulse />}><div className="bio-grid">{incidents.slice(0, 4).map((incident) => <BiometricCard key={incident.id} incident={incident} />)}</div></Panel>
    </div>
  </CommandShell>;
}
