import { createFileRoute } from "@tanstack/react-router";
import { Bulletins, Button, CommandShell, Metric, Panel, TacticalMap, TinyBars, icons, useIncidents } from "@/components/command-ui";

export const Route = createFileRoute("/media")({
  head: () => ({ meta: [
    { title: "GBVF Media Analytics — uMsinga & Inanda" },
    { name: "description", content: "Anonymized GBVF trends and broadcast-ready public interest data for uMsinga and Inanda." },
    { property: "og:title", content: "GBVF Media Analytics — uMsinga & Inanda" },
    { property: "og:description", content: "Verified anonymized GBVF trends for responsible reporting across priority KZN communities." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: MediaPage,
});

function MediaPage() {
  const { incidents } = useIncidents();
  const exportBulletin = () => {
    const text = `BAAS GBVF SITUATION BULLETIN\nKZN NORTH · uMsinga & Inanda\n\n${incidents.filter((i) => i.status === "Active").length} active anonymized alerts under coordinated response. No personal identifiers included.`;
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url; anchor.download = "baas-gbvf-bulletin.txt"; anchor.click(); URL.revokeObjectURL(url);
  };
  return <CommandShell eyebrow="Mode 03 / Anonymized public-interest intelligence" title="Media Analytics Desk" detail="Verified GBVF patterns for responsible reporting — no survivor identities exposed." actions={<Button variant="outline" onClick={exportBulletin}><icons.Download />Export bulletin</Button>}>
    <div className="metric-grid">
      <Metric label="7-Day Incidents" value="38" tone="danger" note="+18% vs prior period" icon={<icons.AlertTriangle />} />
      <Metric label="Inanda Share" value="63" unit="%" tone="amber" note="Township reporting zone" icon={<icons.Signal />} />
      <Metric label="uMsinga Share" value="37" unit="%" note="Rural reporting zone" icon={<icons.Radio />} />
      <Metric label="Verified Signals" value="84" unit="%" tone="success" note="Dual-sensor confidence" icon={<icons.ShieldCheck />} />
      <Metric label="Identity Exposure" value="0" tone="success" note="Privacy controls active" icon={<icons.ShieldCheck />} />
    </div>
    <div className="dashboard-grid media-layout">
      <Panel className="trend-panel" kicker="Rolling 30-day analysis" title="Incident Frequency" icon={<icons.Activity />} aside={<div className="segmented"><span data-active="true">Daily</span><span>Weekly</span></div>}>
        <div className="trend-chart"><div className="chart-axis"><span>12</span><span>8</span><span>4</span><span>0</span></div><div className="trend-lines"><svg viewBox="0 0 800 230" preserveAspectRatio="none"><path className="trend-area" d="M0 190 C80 177 110 91 180 121 S280 172 342 98 S450 84 505 117 S610 54 670 86 S747 25 800 44 L800 230 L0 230Z"/><path className="trend-main" d="M0 190 C80 177 110 91 180 121 S280 172 342 98 S450 84 505 117 S610 54 670 86 S747 25 800 44"/><path className="trend-second" d="M0 204 C90 185 116 169 183 178 S280 130 352 162 S466 137 534 147 S642 103 702 120 S760 81 800 93"/></svg><div className="chart-days"><span>01 Sep</span><span>08 Sep</span><span>15 Sep</span><span>22 Sep</span><span>Today</span></div></div></div>
        <div className="trend-legend"><span><i className="legend-red"/>Inanda township</span><span><i className="legend-amber"/>uMsinga rural</span><strong>Peak window 18:00–23:00</strong></div>
      </Panel>
      <Panel className="media-map" kicker="Anonymized density" title="Vulnerability Heatmap" icon={<icons.Signal />}><TacticalMap compact /></Panel>
      <Panel className="bulletin-panel" kicker="Broadcast-ready output" title="Situation Bulletin" icon={<icons.Radio />} aside={<span className="panel-tag">AUTO-DRAFT</span>}><Bulletins incidents={incidents} /><Button variant="outline" className="full-button" onClick={exportBulletin}><icons.Download />Download anonymized bulletin</Button></Panel>
      <Panel className="comparison-panel" kicker="Area comparison" title="Rural / Township Pattern" icon={<icons.Activity />}>
        <div className="comparison"><div><header><span>Inanda township</span><strong>24 incidents</strong></header><TinyBars values={[2,5,3,8,7,5,9,6,8,10,7,11]} tone="danger" /><footer><span>Peak: 21:00</span><b>+22%</b></footer></div><div><header><span>uMsinga rural</span><strong>14 incidents</strong></header><TinyBars values={[1,2,4,2,5,3,4,6,3,5,4,7]} tone="amber" /><footer><span>Peak: 19:00</span><b>+11%</b></footer></div></div>
      </Panel>
      <Panel className="editorial-panel" kicker="Editorial safeguards" title="Privacy & Verification" icon={<icons.ShieldCheck />}>
        <div className="check-list"><span><icons.CheckCircle2 />Personal identifiers removed</span><span><icons.CheckCircle2 />Coordinates aggregated to area level</span><span><icons.CheckCircle2 />Dual-sensor threshold disclosed</span><span><icons.CheckCircle2 />SAPS case details withheld</span></div>
      </Panel>
    </div>
  </CommandShell>;
}
