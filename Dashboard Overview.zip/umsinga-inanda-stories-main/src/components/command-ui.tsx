import { Link, useRouterState } from "@tanstack/react-router";
import { Activity, AlertTriangle, Antenna, ArrowUpRight, BarChart3, BellRing, CheckCircle2, Clock3, Download, HeartPulse, MapPin, Radio, Shield, ShieldCheck, Signal, Siren, Wifi } from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Button } from "@/components/button";
import { fallbackIncidents, isDualVerified, type Incident } from "@/lib/incident-data";

const nav = [
  { to: "/", label: "Network Health", short: "Network", icon: Antenna },
  { to: "/dispatch", label: "SAPS GBV Dispatch", short: "Dispatch", icon: Siren },
  { to: "/media", label: "News Media Analytics", short: "Media", icon: BarChart3 },
] as const;

export function useIncidents() {
  const [incidents, setIncidents] = useState(fallbackIncidents);
  const [source, setSource] = useState<"live" | "fallback">("fallback");
  useEffect(() => {
    const controller = new AbortController();
    fetch("http://localhost:5000/api/incidents", { signal: controller.signal })
      .then((response) => response.ok ? response.json() : Promise.reject(new Error("Feed unavailable")))
      .then((data) => {
        const rows = Array.isArray(data) ? data : data?.incidents;
        if (Array.isArray(rows) && rows.length) {
          setIncidents(rows);
          setSource("live");
        }
      })
      .catch(() => undefined);
    return () => controller.abort();
  }, []);
  return { incidents, setIncidents, source };
}

export function CommandShell({ children, eyebrow, title, detail, actions }: { children: ReactNode; eyebrow: string; title: string; detail: string; actions?: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="command-header">
        <div className="brand-block">
          <div className="brand-mark"><Shield aria-hidden="true" /></div>
          <div><strong>BAAS</strong><span>GBVF COMMAND / KZN</span></div>
        </div>
        <nav className="mode-nav" aria-label="Operational modes">
          {nav.map(({ to, label, short, icon: Icon }) => (
            <Link key={to} to={to} className="mode-link" data-active={path === to} aria-label={label}>
              <Icon aria-hidden="true" /><span className="mode-full">{label}</span><span className="mode-short">{short}</span>
            </Link>
          ))}
        </nav>
        <div className="header-status">
          <div className="live-pill"><span />LIVE</div>
          <div className="clock"><Clock3 aria-hidden="true" /><span>{now.toLocaleTimeString("en-ZA", { hour12: false })}</span><small>SAST</small></div>
        </div>
      </header>
      <main className="command-main">
        <section className="page-heading">
          <div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{detail}</p></div>
          {actions && <div className="heading-actions">{actions}</div>}
        </section>
        <div className="scope-bar">
          <div><MapPin aria-hidden="true" /><span>PRIMARY COVERAGE</span><strong>uMsinga Rural</strong><i /> <strong>Inanda Township</strong></div>
          <span className="scope-meta">KZN JOINT OPERATIONS AREA · 24/7</span>
        </div>
        {children}
      </main>
    </div>
  );
}

export function Panel({ title, kicker, icon, children, className = "", aside }: { title: string; kicker?: string; icon?: ReactNode; children: ReactNode; className?: string; aside?: ReactNode }) {
  return <section className={`panel ${className}`}><div className="panel-head"><div className="panel-title">{icon}<div>{kicker && <span>{kicker}</span>}<h2>{title}</h2></div></div>{aside}</div>{children}</section>;
}

export function Metric({ label, value, unit, tone = "neutral", note, icon }: { label: string; value: string; unit?: string; tone?: "neutral" | "danger" | "amber" | "success"; note?: string; icon?: ReactNode }) {
  return <article className="metric" data-tone={tone}><div className="metric-label">{icon}{label}</div><div className="metric-value">{value}{unit && <small>{unit}</small>}</div>{note && <div className="metric-note">{note}</div>}</article>;
}

export function TinyBars({ values, tone = "primary" }: { values: number[]; tone?: "primary" | "danger" | "amber" | "success" }) {
  const max = Math.max(...values);
  return <div className="tiny-bars" data-tone={tone} aria-hidden="true">{values.map((v, i) => <span key={`${v}-${i}`} style={{ height: `${Math.max(10, (v / max) * 100)}%` }} />)}</div>;
}

const markers = [
  { id: "uMsinga / Pomeroy", x: 35, y: 31, level: "amber" },
  { id: "uMsinga / Tugela Ferry", x: 43, y: 47, level: "danger" },
  { id: "Inanda / Amaoti", x: 67, y: 66, level: "danger" },
  { id: "Inanda / Newtown C", x: 73, y: 73, level: "danger" },
  { id: "Durban", x: 79, y: 82, level: "muted" },
];

export function TacticalMap({ compact = false }: { compact?: boolean }) {
  return <div className={`tactical-map ${compact ? "tactical-map--compact" : ""}`}>
    <div className="map-grid" />
    <svg className="kzn-outline" viewBox="0 0 700 450" aria-label="Operational map of uMsinga and Inanda in KwaZulu-Natal">
      <path d="M136 28 249 64 326 53 388 92 467 103 514 151 570 188 617 254 598 332 558 405 483 422 424 390 359 401 309 365 242 354 192 307 153 244 112 205 101 129Z" />
      <path className="route-line" d="M245 120 C285 169 279 216 335 240 S433 278 492 345" />
      <path className="route-line secondary" d="M315 85 C341 150 406 177 425 239 S484 288 519 330" />
    </svg>
    {markers.map((marker) => <div key={marker.id} className="map-point" data-level={marker.level} style={{ left: `${marker.x}%`, top: `${marker.y}%` }}><span /><label>{marker.id}</label></div>)}
    <div className="map-label map-label--north">N</div>
    <div className="map-legend"><span><i data-level="danger" />Active distress</span><span><i data-level="amber" />Elevated density</span></div>
  </div>;
}

export function HeartLine({ bpm, critical = false }: { bpm: number; critical?: boolean }) {
  return <div className="heartline" data-critical={critical}><svg viewBox="0 0 500 72" preserveAspectRatio="none" aria-label={`Heart rate ${bpm} beats per minute`}><path d="M0 40 L55 40 L69 34 L82 43 L97 39 L117 40 L129 13 L143 62 L157 25 L172 40 L226 40 L242 35 L254 42 L270 40 L290 40 L303 12 L318 61 L333 24 L350 40 L410 40 L424 36 L439 43 L454 40 L500 40" /></svg><strong>{bpm}<small>BPM</small></strong></div>;
}

export function BiometricCard({ incident }: { incident: Incident }) {
  const verified = isDualVerified(incident);
  return <article className="bio-card" data-critical={verified}>
    <div className="bio-top"><div><span>{incident.node}</span><strong>{incident.locality}</strong></div><span className="status-badge" data-status={incident.status}>{incident.status}</span></div>
    <HeartLine bpm={incident.heart_rate_bpm} critical={verified} />
    <div className="bio-readings"><span><Activity />NOISE <strong>{incident.noise_level_db} dB</strong></span><span><Radio />SIGNAL <strong>-67 dBm</strong></span></div>
    {verified && <div className="verification"><AlertTriangle />CRITICAL DISTRESS · AUDIO + BIOMETRIC MATCH</div>}
  </article>;
}

export function StatusDot({ status }: { status: string }) { return <span className="table-status" data-status={status}><i />{status}</span>; }

export function IncidentsTable({ incidents, selected, onSelect }: { incidents: Incident[]; selected?: string | undefined; onSelect?: (incident: Incident) => void }) {
  return <div className="table-wrap"><table><thead><tr><th>Incident</th><th>Location</th><th>Signal</th><th>Status</th><th>Reported</th></tr></thead><tbody>{incidents.map((incident) => <tr key={incident.id} data-selected={selected === incident.id} onClick={() => onSelect?.(incident)}><td><strong>{incident.id}</strong><small>{incident.priority}</small></td><td>{incident.locality}<small>{incident.area}</small></td><td><span className="signal-cell"><HeartPulse />{incident.heart_rate_bpm} BPM</span></td><td><StatusDot status={incident.status} /></td><td>{incident.reportedAt}</td></tr>)}</tbody></table></div>;
}

export function NetworkNode({ name, location, signal, battery, online = true }: { name: string; location: string; signal: number; battery: number; online?: boolean }) {
  return <div className="network-node"><div className="node-icon" data-online={online}><Wifi /></div><div><strong>{name}</strong><span>{location}</span></div><div className="node-metrics"><span>{signal} dBm</span><span>{battery}% PWR</span></div><span className="node-state" data-online={online}>{online ? "ONLINE" : "DEGRADED"}</span></div>;
}

export function Bulletins({ incidents }: { incidents: Incident[] }) {
  const active = incidents.filter((i) => i.status === "Active").length;
  return <div className="bulletin"><div className="bulletin-top"><span>FOR IMMEDIATE BROADCAST</span><strong>GBVF SITUATION BULLETIN · KZN NORTH</strong></div><h3>{active} active alerts under coordinated response across priority communities</h3><p>Anonymized BAAS network data indicates elevated incident activity in Inanda township, with persistent vulnerability signals along rural transit corridors in uMsinga. No personal identifiers are included.</p><div className="bulletin-stats"><span><strong>+18%</strong>7-day frequency</span><span><strong>08:42</strong>median response</span><span><strong>94.7%</strong>mesh coverage</span></div><footer><ShieldCheck /> VERIFIED AGGREGATE · BAAS COMMAND NETWORK <ArrowUpRight /></footer></div>;
}

export const icons = { Activity, AlertTriangle, Antenna, BellRing, CheckCircle2, Download, HeartPulse, Radio, ShieldCheck, Signal, Siren, Wifi };
export { Button };
