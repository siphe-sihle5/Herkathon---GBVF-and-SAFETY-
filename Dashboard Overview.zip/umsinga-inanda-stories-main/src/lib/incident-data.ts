export type IncidentStatus = "Active" | "En Route" | "Resolved" | "Monitoring";
export type Incident = {
  id: string;
  area: "uMsinga" | "Inanda";
  locality: string;
  latitude: number;
  longitude: number;
  status: IncidentStatus;
  heart_rate_bpm: number;
  noise_level_db: number;
  reportedAt: string;
  priority: "Critical" | "High" | "Moderate";
  node: string;
};

export const fallbackIncidents: Incident[] = [
  { id: "GBV-2409", area: "Inanda", locality: "Newtown C", latitude: -29.704, longitude: 30.934, status: "Active", heart_rate_bpm: 151, noise_level_db: 782, reportedAt: "21:18", priority: "Critical", node: "IN-NC-044" },
  { id: "GBV-2408", area: "uMsinga", locality: "Tugela Ferry", latitude: -28.747, longitude: 30.456, status: "En Route", heart_rate_bpm: 136, noise_level_db: 721, reportedAt: "21:11", priority: "Critical", node: "UM-TF-019" },
  { id: "GBV-2407", area: "Inanda", locality: "Amaoti", latitude: -29.691, longitude: 30.961, status: "Active", heart_rate_bpm: 142, noise_level_db: 745, reportedAt: "20:57", priority: "Critical", node: "IN-AM-027" },
  { id: "GBV-2406", area: "uMsinga", locality: "Pomeroy", latitude: -28.552, longitude: 30.337, status: "Monitoring", heart_rate_bpm: 118, noise_level_db: 604, reportedAt: "20:42", priority: "High", node: "UM-PO-008" },
  { id: "GBV-2405", area: "Inanda", locality: "KwaMashu border", latitude: -29.733, longitude: 30.981, status: "Resolved", heart_rate_bpm: 92, noise_level_db: 412, reportedAt: "20:14", priority: "Moderate", node: "IN-KB-031" },
];

export function isDualVerified(incident: Incident) {
  return incident.noise_level_db > 700 && incident.heart_rate_bpm > 130;
}
